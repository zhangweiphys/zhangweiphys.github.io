# GitHub Pages 部署指南

## 🎉 你的炫酷物理主题个人主页已经准备好了！

### 在线预览
**临时预览地址**: https://mwnvudo356oq2.ok.kimi.link

---

## 📋 部署步骤

### 第一步：克隆你的 GitHub Pages 仓库

```bash
git clone https://github.com/zhangweiphys/zhangweiphys.github.io.git
cd zhangweiphys.github.io
```

### 第二步：复制构建文件

将 `dist` 文件夹中的所有文件复制到你的仓库中：

```bash
# 假设 dist 文件夹在当前目录的上一级
cp -r /path/to/dist/* .
```

或者直接下载本项目的 `dist` 文件夹内容，解压后复制到仓库根目录。

### 第三步：提交并推送

```bash
# 添加所有文件
git add .

# 提交更改
git commit -m "Initial commit: Add physics-themed portfolio website"

# 推送到 GitHub
git push origin main
```

### 第四步：启用 GitHub Pages

1. 访问 https://github.com/zhangweiphys/zhangweiphys.github.io
2. 点击 **Settings** 标签
3. 在左侧菜单中找到 **Pages**
4. 在 **Source** 部分，选择 **Deploy from a branch**
5. 选择 **main** 分支，文件夹选择 **/(root)**
6. 点击 **Save**

### 第五步：访问你的主页

等待几分钟（通常2-5分钟），然后访问：

**https://zhangweiphys.github.io**

---

## 🎨 网站特色

### 视觉设计
- **深色主题**：黑色背景配合霓虹蓝/紫/粉渐变
- **3D粒子系统**：300+粒子围绕鼠标形成引力井效果
- **动态网格**：背景网格随鼠标移动产生时空扭曲
- **玻璃态效果**：卡片使用毛玻璃背景

### 动画效果
- **文字解码动画**：标题像密码一样逐字解码显示
- **滚动触发动画**：每个区域进入视口时都有精心设计的入场动画
- **悬停交互**：卡片悬停时有发光和上浮效果
- **量子纠缠表单**：联系表单根据输入内容产生视觉反馈

### 页面结构
1. **Hero区域**：3D粒子背景 + 解码动画标题
2. **关于我**：个人介绍 + 数据统计卡片
3. **研究领域**：4个研究方向卡片
4. **技术栈**：交互式技术标签云
5. **研究成果**：动态数字统计 + 论文列表
6. **联系表单**：量子纠缠视觉效果

---

## 🔧 自定义修改

### 修改个人信息

编辑以下文件：

| 文件 | 内容 |
|------|------|
| `src/sections/Hero.tsx` | 标题、副标题 |
| `src/sections/About.tsx` | 个人介绍、统计数据 |
| `src/sections/Research.tsx` | 研究领域 |
| `src/sections/TechStack.tsx` | 技术栈 |
| `src/sections/Publications.tsx` | 论文列表 |
| `src/sections/Contact.tsx` | 联系方式、社交链接 |

### 修改后重新构建

```bash
cd /mnt/okcomputer/output/app
npm run build
```

然后将新的 `dist` 文件夹内容复制到仓库并推送。

---

## 🚀 高级配置

### 自定义域名（可选）

如果你想使用自定义域名（如 `yourdomain.com`）：

1. 在仓库根目录创建 `CNAME` 文件
2. 在文件中写入你的域名：
   ```
   yourdomain.com
   ```
3. 在你的域名DNS设置中添加 CNAME 记录指向 `zhangweiphys.github.io`
4. 在 GitHub Pages 设置中配置自定义域名

### 启用 HTTPS

GitHub Pages 自动为 `.github.io` 域名启用 HTTPS。如果你使用自定义域名，在 Pages 设置中勾选 **Enforce HTTPS**。

---

## 📁 文件结构

```
zhangweiphys.github.io/
├── index.html              # 入口文件
├── assets/
│   ├── index-*.js         # JavaScript  bundle
│   └── index-*.css        # CSS bundle
└── CNAME (可选)            # 自定义域名配置
```

---

## 🆘 常见问题

### 页面显示空白
- 检查浏览器控制台是否有错误
- 确认 `base` 配置在 `vite.config.ts` 中设置正确
- 确保所有资源文件路径正确

### 样式没有生效
- 清除浏览器缓存（Ctrl+Shift+R 或 Cmd+Shift+R）
- 检查 CSS 文件是否正确加载

### 3D效果不显示
- 确保浏览器支持 WebGL
- 尝试更新显卡驱动
- 在移动设备上可能会有性能限制

---

## 💡 技术栈

- **React 18** - UI框架
- **TypeScript** - 类型安全
- **Vite** - 构建工具
- **Tailwind CSS** - 样式框架
- **Three.js / React Three Fiber** - 3D图形
- **GSAP** - 动画库

---

## 📞 需要帮助？

如果你遇到任何问题，可以：
1. 检查 GitHub Pages 文档：https://docs.github.com/en/pages
2. 查看仓库的 Actions 标签页了解部署状态
3. 在浏览器开发者工具中查看控制台错误

---

**祝你的学术之路如宇宙般广阔！** 🌌✨
