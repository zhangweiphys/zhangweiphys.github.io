import { Atom, Heart } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative w-full py-8 px-4 border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Logo & Copyright */}
          <div className="flex items-center gap-2">
            <Atom className="w-5 h-5 text-[#3898ec]" />
            <span className="font-mono text-sm text-gray-400">
              zhangweiphys © {currentYear}
            </span>
          </div>

          {/* Made with */}
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-[#ff61dc] fill-[#ff61dc]" />
            <span>and</span>
            <span className="text-[#3898ec]">Physics</span>
          </div>

          {/* Quote */}
          <div className="text-xs text-gray-600 font-mono hidden lg:block">
            "The universe is under no obligation to make sense to us."
          </div>
        </div>
      </div>
    </footer>
  );
}
