import { useRef, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface GravityGridProps {
  mousePosition: React.MutableRefObject<{ x: number; y: number }>;
}

export function GravityGrid({ mousePosition }: GravityGridProps) {
  const meshRef = useRef<THREE.LineSegments>(null);
  const { viewport } = useThree();
  
  const { geometry, positions } = useMemo(() => {
    const size = 100;
    const divisions = 30;
    const step = size / divisions;
    const positions: number[] = [];
    
    // Horizontal lines
    for (let i = 0; i <= divisions; i++) {
      const y = (i * step) - size / 2;
      for (let j = 0; j < divisions; j++) {
        const x1 = (j * step) - size / 2;
        const x2 = ((j + 1) * step) - size / 2;
        positions.push(x1, y, 0, x2, y, 0);
      }
    }
    
    // Vertical lines
    for (let i = 0; i <= divisions; i++) {
      const x = (i * step) - size / 2;
      for (let j = 0; j < divisions; j++) {
        const y1 = (j * step) - size / 2;
        const y2 = ((j + 1) * step) - size / 2;
        positions.push(x, y1, 0, x, y2, 0);
      }
    }
    
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    
    return { geometry, positions: new Float32Array(positions) };
  }, []);

  const originalPositions = useMemo(() => new Float32Array(positions), [positions]);

  useFrame((state) => {
    if (!meshRef.current) return;
    
    const time = state.clock.getElapsedTime();
    const positionAttribute = meshRef.current.geometry.attributes.position;
    const posArray = positionAttribute.array as Float32Array;
    
    const mouseX = (mousePosition.current.x / window.innerWidth) * 2 - 1;
    const mouseY = -(mousePosition.current.y / window.innerHeight) * 2 + 1;
    
    // Convert mouse to world space
    const worldMouseX = mouseX * viewport.width / 2;
    const worldMouseY = mouseY * viewport.height / 2;
    
    for (let i = 0; i < posArray.length; i += 3) {
      const origX = originalPositions[i];
      const origY = originalPositions[i + 1];
      
      // Distance from mouse
      const dx = origX - worldMouseX;
      const dy = origY - worldMouseY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      
      // Gravity well effect
      const gravityRadius = 15;
      const gravityStrength = 3;
      
      if (dist < gravityRadius && dist > 0.1) {
        const force = (1 - dist / gravityRadius) * gravityStrength;
        const angle = Math.atan2(dy, dx);
        
        // Spiral effect
        const spiralAngle = angle + time * 0.5;
        posArray[i] = origX + Math.cos(spiralAngle) * force;
        posArray[i + 1] = origY + Math.sin(spiralAngle) * force;
        posArray[i + 2] = Math.sin(time + dist * 0.1) * force * 0.3;
      } else {
        // Gentle wave for far points
        posArray[i] = origX + Math.sin(time * 0.5 + origY * 0.1) * 0.2;
        posArray[i + 1] = origY + Math.cos(time * 0.3 + origX * 0.1) * 0.2;
        posArray[i + 2] = Math.sin(time * 0.2 + (origX + origY) * 0.05) * 0.5;
      }
    }
    
    positionAttribute.needsUpdate = true;
  });

  return (
    <lineSegments ref={meshRef} geometry={geometry}>
      <lineBasicMaterial 
        color="#3898ec" 
        transparent 
        opacity={0.15}
        blending={THREE.AdditiveBlending}
      />
    </lineSegments>
  );
}
