import { useRef, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface ParticleFieldProps {
  count?: number;
  mousePosition: React.MutableRefObject<{ x: number; y: number }>;
}

export function ParticleField({ count = 200, mousePosition }: ParticleFieldProps) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const { viewport } = useThree();
  
  const particles = useMemo(() => {
    const temp = [];
    for (let i = 0; i < count; i++) {
      const t = Math.random() * 100;
      const factor = 20 + Math.random() * 100;
      const speed = 0.01 + Math.random() * 0.02;
      const xFactor = -50 + Math.random() * 100;
      const yFactor = -50 + Math.random() * 100;
      const zFactor = -50 + Math.random() * 100;
      temp.push({ t, factor, speed, xFactor, yFactor, zFactor, mx: 0, my: 0 });
    }
    return temp;
  }, [count]);

  const dummy = useMemo(() => new THREE.Object3D(), []);
  const colors = useMemo(() => {
    const colorArray = new Float32Array(count * 3);
    const color1 = new THREE.Color('#3898ec');
    const color2 = new THREE.Color('#7b61ff');
    const color3 = new THREE.Color('#ff61dc');
    
    for (let i = 0; i < count; i++) {
      const mixRatio = Math.random();
      let color;
      if (mixRatio < 0.33) {
        color = color1.clone().lerp(color2, Math.random());
      } else if (mixRatio < 0.66) {
        color = color2.clone().lerp(color3, Math.random());
      } else {
        color = color3.clone().lerp(color1, Math.random());
      }
      colorArray[i * 3] = color.r;
      colorArray[i * 3 + 1] = color.g;
      colorArray[i * 3 + 2] = color.b;
    }
    return colorArray;
  }, [count]);

  useFrame(() => {
    if (!meshRef.current) return;
    
    const mouseX = (mousePosition.current.x / window.innerWidth) * 2 - 1;
    const mouseY = -(mousePosition.current.y / window.innerHeight) * 2 + 1;
    
    particles.forEach((particle, i) => {
      let { t, factor, speed, xFactor, yFactor, zFactor } = particle;
      
      t = particle.t += speed;
      
      const a = Math.cos(t) + Math.sin(t * 1) / 10;
      const b = Math.sin(t) + Math.cos(t * 2) / 10;
      const s = Math.max(0.1, Math.cos(t) * 0.5 + 0.5);
      
      // Mouse influence
      const dx = mouseX * viewport.width / 2 - (a * factor + xFactor);
      const dy = mouseY * viewport.height / 2 - (b * factor + yFactor);
      const dist = Math.sqrt(dx * dx + dy * dy);
      const attraction = Math.max(0, 1 - dist / 10);
      
      particle.mx += (dx * attraction * 0.01 - particle.mx) * 0.1;
      particle.my += (dy * attraction * 0.01 - particle.my) * 0.1;
      
      dummy.position.set(
        a * factor + xFactor + particle.mx,
        b * factor + yFactor + particle.my,
        Math.sin(t * 2) * 10 + zFactor
      );
      
      dummy.scale.set(s, s, s);
      dummy.rotation.set(t * 0.5, t * 0.3, t * 0.2);
      dummy.updateMatrix();
      
      meshRef.current!.setMatrixAt(i, dummy.matrix);
    });
    
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[0.15, 8, 8]}>
        <instancedBufferAttribute
          attach="attributes-color"
          args={[colors, 3]}
        />
      </sphereGeometry>
      <meshBasicMaterial vertexColors toneMapped={false} />
    </instancedMesh>
  );
}
