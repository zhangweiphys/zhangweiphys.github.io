import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Atom, Code, BookOpen } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  { icon: Atom, label: '模拟经验', value: '5年+' },
  { icon: Code, label: '编程语言', value: 'Python & C++' },
  { icon: BookOpen, label: '发表论文', value: '10+' },
];

export function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Image reveal animation
      gsap.fromTo(
        imageRef.current,
        { clipPath: 'polygon(0 0, 0 0, 0 100%, 0 100%)' },
        {
          clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)',
          duration: 1.2,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Content slide in
      gsap.fromTo(
        contentRef.current,
        { x: 100, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 1,
          delay: 0.3,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Stats stagger
      const statItems = statsRef.current?.children;
      if (statItems) {
        gsap.fromTo(
          statItems,
          { x: 20, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.5,
            stagger: 0.1,
            delay: 0.5,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 60%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative min-h-screen w-full flex items-center py-20 px-4 sm:px-8 lg:px-16"
    >
      <div className="max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image Side */}
          <div
            ref={imageRef}
            className="relative aspect-[4/3] rounded-2xl overflow-hidden"
            style={{ clipPath: 'polygon(0 0, 0 0, 0 100%, 0 100%)' }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-[#3898ec]/20 to-[#7b61ff]/20" />
            <img
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=600&fit=crop"
              alt="Researcher"
              className="w-full h-full object-cover"
            />
            {/* Decorative elements */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 border-2 border-[#3898ec] rounded-lg opacity-50" />
            <div className="absolute -top-4 -left-4 w-16 h-16 border-2 border-[#7b61ff] rounded-full opacity-50" />
          </div>

          {/* Content Side */}
          <div ref={contentRef} className="space-y-6 opacity-0">
            <h2 className="text-4xl sm:text-5xl font-bold">
              关于<span className="gradient-text">我</span>
            </h2>
            
            <div className="space-y-4 text-gray-300 text-lg leading-relaxed">
              <p>
                我是一名<span className="text-[#3898ec] font-semibold">物理学博士生</span>，
                专注于<span className="text-[#7b61ff] font-semibold">计算天体物理学</span>。
                我的研究涉及模拟星系形成和黑洞吸积盘。
              </p>
              <p>
                通过高性能计算和先进的数值方法，我致力于揭示宇宙中最神秘现象背后的物理机制。
                从星系尺度的结构形成，到黑洞周围的极端物理环境，每一个模拟都是一次探索未知的旅程。
              </p>
            </div>

            {/* Stats */}
            <div ref={statsRef} className="grid grid-cols-3 gap-4 pt-6">
              {stats.map((stat, index) => (
                <div
                  key={index}
                  className="physics-card text-center group cursor-default"
                >
                  <stat.icon 
                    className="w-8 h-8 mx-auto mb-2 text-[#3898ec] group-hover:text-[#7b61ff] transition-colors" 
                  />
                  <div className="text-2xl font-bold text-white mb-1">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Background decoration */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-[#3898ec]/5 rounded-full blur-3xl -translate-y-1/2" />
    </section>
  );
}
