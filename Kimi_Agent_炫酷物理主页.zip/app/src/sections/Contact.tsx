import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Github, Twitter, MapPin, Send, Atom } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const socialLinks = [
  { icon: Github, label: 'GitHub', url: 'https://github.com/zhangweiphys', color: '#3898ec' },
  { icon: Twitter, label: 'Twitter', url: '#', color: '#7b61ff' },
  { icon: Mail, label: 'Email', url: 'mailto:zhangwei@example.edu', color: '#ff61dc' },
];

export function Contact() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const visualRef = useRef<HTMLDivElement>(null);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Form animation
      gsap.fromTo(
        formRef.current,
        { x: -50, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Visual animation
      gsap.fromTo(
        visualRef.current,
        { x: 50, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setSubmitted(true);
    setFormData({ name: '', email: '', message: '' });
    
    // Reset submitted state after 3 seconds
    setTimeout(() => setSubmitted(false), 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  // Calculate entanglement intensity based on form fill
  const entanglementIntensity = (formData.name ? 0.3 : 0) + 
                                 (formData.email ? 0.3 : 0) + 
                                 (formData.message ? 0.4 : 0);

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative min-h-screen w-full flex items-center py-20 px-4 sm:px-8 lg:px-16"
    >
      <div className="max-w-7xl mx-auto w-full">
        {/* Title */}
        <div ref={titleRef} className="text-center mb-16 opacity-0">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            联系<span className="gradient-text">我</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            开启学术合作，探索宇宙奥秘
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Form Side */}
          <form
            ref={formRef}
            onSubmit={handleSubmit}
            className="space-y-6 opacity-0"
          >
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                姓名
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-lg focus:border-[#3898ec] focus:ring-1 focus:ring-[#3898ec] outline-none transition-all text-white"
                placeholder="您的姓名"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                邮箱
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-lg focus:border-[#7b61ff] focus:ring-1 focus:ring-[#7b61ff] outline-none transition-all text-white"
                placeholder="your@email.com"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                消息
              </label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows={5}
                className="w-full px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-lg focus:border-[#ff61dc] focus:ring-1 focus:ring-[#ff61dc] outline-none transition-all text-white resize-none"
                placeholder="写下您的消息..."
                required
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <Atom className="w-5 h-5 animate-spin" />
              ) : submitted ? (
                '发送成功!'
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  发送消息
                </>
              )}
            </button>
          </form>

          {/* Visual Side */}
          <div ref={visualRef} className="flex flex-col justify-center opacity-0">
            {/* Quantum Entanglement Visualization */}
            <div className="relative h-64 mb-8">
              <div className="absolute inset-0 flex items-center justify-center">
                {/* Particle 1 */}
                <div 
                  className="absolute left-1/4 top-1/2 -translate-y-1/2 w-16 h-16 rounded-full transition-all duration-500"
                  style={{
                    background: `radial-gradient(circle, #3898ec, transparent)`,
                    boxShadow: `0 0 ${20 + entanglementIntensity * 30}px #3898ec`,
                    opacity: 0.3 + entanglementIntensity * 0.7,
                  }}
                />
                
                {/* Particle 2 */}
                <div 
                  className="absolute right-1/4 top-1/2 -translate-y-1/2 w-16 h-16 rounded-full transition-all duration-500"
                  style={{
                    background: `radial-gradient(circle, #7b61ff, transparent)`,
                    boxShadow: `0 0 ${20 + entanglementIntensity * 30}px #7b61ff`,
                    opacity: 0.3 + entanglementIntensity * 0.7,
                  }}
                />
                
                {/* Energy beam connection */}
                <div 
                  className="absolute left-1/4 right-1/4 top-1/2 h-0.5 -translate-y-1/2 transition-all duration-500"
                  style={{
                    background: `linear-gradient(90deg, #3898ec, #7b61ff)`,
                    opacity: 0.2 + entanglementIntensity * 0.8,
                    boxShadow: `0 0 ${10 + entanglementIntensity * 20}px ${entanglementIntensity > 0.5 ? '#ff61dc' : 'transparent'}`,
                  }}
                />

                {/* Orbiting particles when form is filled */}
                {entanglementIntensity > 0.5 && (
                  <>
                    <div className="absolute left-1/4 top-1/2 w-4 h-4 bg-[#ff61dc] rounded-full animate-orbit" />
                    <div className="absolute right-1/4 top-1/2 w-4 h-4 bg-[#ff61dc] rounded-full animate-orbit" style={{ animationDelay: '0.5s' }} />
                  </>
                )}
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-gray-400">
                <MapPin className="w-5 h-5 text-[#3898ec]" />
                <span>某大学物理系，天体物理研究中心</span>
              </div>

              {/* Social Links */}
              <div className="flex gap-4 pt-4">
                {socialLinks.map((link, index) => (
                  <a
                    key={index}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 rounded-lg flex items-center justify-center transition-all hover:scale-110"
                    style={{
                      backgroundColor: `${link.color}20`,
                      border: `1px solid ${link.color}40`,
                    }}
                    title={link.label}
                  >
                    <link.icon className="w-5 h-5" style={{ color: link.color }} />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-[#3898ec]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-[#7b61ff]/5 rounded-full blur-3xl" />

      <style>{`
        @keyframes orbit {
          from { transform: rotate(0deg) translateX(40px) rotate(0deg); }
          to { transform: rotate(360deg) translateX(40px) rotate(-360deg); }
        }
        .animate-orbit {
          animation: orbit 2s linear infinite;
        }
      `}</style>
    </section>
  );
}
