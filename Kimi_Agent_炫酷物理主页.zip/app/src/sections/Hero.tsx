import { useEffect, useRef, useState } from 'react';
import { Scene } from '../components/three/Scene';
import { ChevronDown } from 'lucide-react';
import gsap from 'gsap';

export function Hero() {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [displayText, setDisplayText] = useState('');
  const fullText = 'zhangweiphys';
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';

  // Text decode animation
  useEffect(() => {
    let iteration = 0;
    const totalIterations = fullText.length * 3;
    
    const interval = setInterval(() => {
      setDisplayText(
        fullText
          .split('')
          .map((_, index) => {
            if (index < iteration / 3) {
              return fullText[index];
            }
            return chars[Math.floor(Math.random() * chars.length)];
          })
          .join('')
      );
      
      iteration++;
      
      if (iteration >= totalIterations) {
        clearInterval(interval);
        setDisplayText(fullText);
      }
    }, 50);

    return () => clearInterval(interval);
  }, []);

  // GSAP animations
  useEffect(() => {
    const ctx = gsap.context(() => {
      // Subtitle animation
      gsap.fromTo(
        subtitleRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.8, delay: 1.5, ease: 'power3.out' }
      );

      // Button animation
      gsap.fromTo(
        buttonRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.8, delay: 1.8, ease: 'power3.out' }
      );

      // Scroll indicator animation
      gsap.to('.scroll-indicator', {
        y: 10,
        repeat: -1,
        yoyo: true,
        duration: 1,
        ease: 'power1.inOut'
      });
    }, containerRef);

    return () => ctx.revert();
  }, []);

  const scrollToAbout = () => {
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section 
      ref={containerRef}
      className="relative min-h-screen w-full flex items-center justify-center overflow-hidden"
    >
      {/* 3D Background */}
      <Scene />
      
      {/* Content */}
      <div className="relative z-10 text-center px-4">
        {/* Main Title */}
        <h1 
          ref={titleRef}
          className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-bold mb-6 font-mono tracking-tight"
        >
          <span className="gradient-text">{displayText}</span>
        </h1>
        
        {/* Subtitle */}
        <p 
          ref={subtitleRef}
          className="text-lg sm:text-xl md:text-2xl text-gray-300 mb-8 opacity-0"
        >
          <span className="text-[#3898ec]">物理学博士生</span>
          <span className="mx-3">|</span>
          <span className="text-[#7b61ff]">天体物理学家</span>
        </p>
        
        {/* CTA Button */}
        <button
          ref={buttonRef}
          onClick={scrollToAbout}
          className="btn-primary text-lg opacity-0"
        >
          探索研究
        </button>
      </div>

      {/* Scroll Indicator */}
      <div className="scroll-indicator absolute bottom-8 left-1/2 -translate-x-1/2 text-gray-400">
        <ChevronDown size={32} className="animate-bounce" />
      </div>

      {/* Gradient Overlays */}
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-black to-transparent z-[5]" />
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black to-transparent z-[5]" />
    </section>
  );
}
