import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { FileText, Quote, TrendingUp, Award } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  { icon: FileText, label: '发表论文', value: 15, suffix: '+' },
  { icon: Quote, label: '被引次数', value: 500, suffix: '+' },
  { icon: TrendingUp, label: 'h-index', value: 12, suffix: '' },
  { icon: Award, label: '学术奖项', value: 3, suffix: '' },
];

const publications = [
  {
    title: 'The Role of Feedback in Galaxy Formation',
    journal: 'The Astrophysical Journal',
    year: 2024,
    citations: 45,
  },
  {
    title: 'Black Hole Accretion Disk Simulations with GPU Acceleration',
    journal: 'Monthly Notices of the Royal Astronomical Society',
    year: 2023,
    citations: 78,
  },
  {
    title: 'Cosmological Hydrodynamical Simulations: Methods and Applications',
    journal: 'Nature Astronomy',
    year: 2023,
    citations: 120,
  },
  {
    title: 'Turbulence in the Interstellar Medium: A Numerical Study',
    journal: 'The Astrophysical Journal Letters',
    year: 2022,
    citations: 56,
  },
];

export function Publications() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const pubsRef = useRef<HTMLDivElement>(null);
  const [animatedValues, setAnimatedValues] = useState<number[]>(stats.map(() => 0));

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Stats animation with number counting
      ScrollTrigger.create({
        trigger: statsRef.current,
        start: 'top 70%',
        onEnter: () => {
          stats.forEach((stat, index) => {
            gsap.to(
              { value: 0 },
              {
                value: stat.value,
                duration: 2,
                ease: 'power2.out',
                onUpdate: function () {
                  setAnimatedValues(prev => {
                    const newValues = [...prev];
                    newValues[index] = Math.round(this.targets()[0].value);
                    return newValues;
                  });
                },
              }
            );
          });
        },
        once: true,
      });

      // Stats cards animation
      const statCards = statsRef.current?.children;
      if (statCards) {
        gsap.fromTo(
          statCards,
          { y: 50, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: statsRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Publications animation
      const pubItems = pubsRef.current?.children;
      if (pubItems) {
        gsap.fromTo(
          pubItems,
          { x: -50, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.15,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: pubsRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="publications"
      ref={sectionRef}
      className="relative min-h-screen w-full flex items-center py-20 px-4 sm:px-8 lg:px-16"
    >
      <div className="max-w-7xl mx-auto w-full">
        {/* Title */}
        <div ref={titleRef} className="text-center mb-16 opacity-0">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            研究<span className="gradient-text">成果</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            学术贡献与发表记录
          </p>
        </div>

        {/* Stats Grid */}
        <div
          ref={statsRef}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-16"
        >
          {stats.map((stat, index) => (
            <div
              key={index}
              className="physics-card text-center group hover:scale-105 transition-transform"
            >
              <stat.icon className="w-8 h-8 mx-auto mb-3 text-[#3898ec] group-hover:text-[#7b61ff] transition-colors" />
              <div className="text-4xl lg:text-5xl font-bold gradient-text mb-1">
                {animatedValues[index]}{stat.suffix}
              </div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Publications List */}
        <div className="space-y-4">
          <h3 className="text-2xl font-bold mb-6 text-center">
            代表性论文
          </h3>
          <div ref={pubsRef} className="space-y-4">
            {publications.map((pub, index) => (
              <div
                key={index}
                className="physics-card group cursor-pointer"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex-1">
                    <h4 className="text-lg font-semibold text-white group-hover:text-[#3898ec] transition-colors mb-1">
                      {pub.title}
                    </h4>
                    <div className="flex items-center gap-3 text-sm text-gray-400">
                      <span className="text-[#7b61ff]">{pub.journal}</span>
                      <span>•</span>
                      <span>{pub.year}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Quote className="w-4 h-4 text-[#ff61dc]" />
                    <span className="text-gray-300">被引</span>
                    <span className="text-[#ff61dc] font-bold">{pub.citations}</span>
                    <span className="text-gray-300">次</span>
                  </div>
                </div>

                {/* Hover line effect */}
                <div className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#3898ec] to-[#7b61ff] w-0 group-hover:w-full transition-all duration-500" />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-1/3 right-0 w-96 h-96 bg-[#3898ec]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/3 left-0 w-96 h-96 bg-[#7b61ff]/5 rounded-full blur-3xl" />
    </section>
  );
}
