import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Orbit, CircleDot, Waves, Cpu } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const researchAreas = [
  {
    icon: Orbit,
    title: '星系形成',
    description: '通过大规模数值模拟研究星系从暗物质晕中的形成与演化过程，探索恒星形成与反馈机制。',
    color: '#3898ec',
  },
  {
    icon: CircleDot,
    title: '黑洞物理',
    description: '研究超大质量黑洞的吸积过程、喷流形成机制，以及黑洞与宿主星系的协同演化关系。',
    color: '#7b61ff',
  },
  {
    icon: Waves,
    title: '宇宙流体动力学',
    description: '开发高精度流体动力学模拟代码，研究宇宙中的激波、湍流和磁流体动力学过程。',
    color: '#ff61dc',
  },
  {
    icon: Cpu,
    title: '高性能计算',
    description: '优化并行算法，利用GPU加速和分布式计算技术，实现超大规模宇宙学模拟。',
    color: '#3898ec',
  },
];

export function Research() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards stagger animation
      const cards = cardsRef.current?.children;
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 80, opacity: 0, rotateY: -15 },
          {
            y: 0,
            opacity: 1,
            rotateY: 0,
            duration: 0.8,
            stagger: 0.15,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="research"
      ref={sectionRef}
      className="relative min-h-screen w-full flex items-center py-20 px-4 sm:px-8 lg:px-16"
    >
      <div className="max-w-7xl mx-auto w-full">
        {/* Title */}
        <div ref={titleRef} className="text-center mb-16 opacity-0">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            研究<span className="gradient-text">领域</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            探索宇宙的奥秘，从星系尺度到黑洞视界
          </p>
        </div>

        {/* Research Cards */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8"
        >
          {researchAreas.map((area, index) => (
            <div
              key={index}
              className="physics-card group cursor-pointer"
              style={{ perspective: '1000px' }}
            >
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div
                  className="flex-shrink-0 w-14 h-14 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110"
                  style={{ backgroundColor: `${area.color}20` }}
                >
                  <area.icon
                    className="w-7 h-7 transition-colors"
                    style={{ color: area.color }}
                  />
                </div>

                {/* Content */}
                <div className="flex-1">
                  <h3
                    className="text-xl font-bold mb-2 transition-colors"
                    style={{ color: area.color }}
                  >
                    {area.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    {area.description}
                  </p>
                </div>
              </div>

              {/* Hover glow effect */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                style={{
                  background: `radial-gradient(circle at 50% 50%, ${area.color}10, transparent 70%)`,
                }}
              />

              {/* Corner decoration */}
              <div
                className="absolute top-0 right-0 w-20 h-20 opacity-0 group-hover:opacity-100 transition-opacity"
                style={{
                  background: `linear-gradient(135deg, transparent 50%, ${area.color}20 50%)`,
                }}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-1/4 right-0 w-64 h-64 bg-[#7b61ff]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 left-0 w-64 h-64 bg-[#3898ec]/5 rounded-full blur-3xl" />
    </section>
  );
}
