import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const technologies = [
  { name: 'Python', level: 95, color: '#3898ec', connections: ['NumPy', 'SciPy', 'Matplotlib'] },
  { name: 'C++', level: 90, color: '#7b61ff', connections: ['CUDA', 'MPI'] },
  { name: 'CUDA', level: 85, color: '#ff61dc', connections: ['C++', 'GPU'] },
  { name: 'MPI', level: 80, color: '#3898ec', connections: ['C++', 'HPC'] },
  { name: 'NumPy', level: 95, color: '#7b61ff', connections: ['Python', 'SciPy'] },
  { name: 'SciPy', level: 90, color: '#ff61dc', connections: ['Python', 'NumPy'] },
  { name: 'Matplotlib', level: 88, color: '#3898ec', connections: ['Python'] },
  { name: 'Linux', level: 92, color: '#7b61ff', connections: ['HPC'] },
  { name: 'LaTeX', level: 85, color: '#ff61dc', connections: [] },
  { name: 'Git', level: 88, color: '#3898ec', connections: [] },
  { name: 'Docker', level: 75, color: '#7b61ff', connections: [] },
  { name: 'TensorFlow', level: 70, color: '#ff61dc', connections: ['Python'] },
];

export function TechStack() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const cloudRef = useRef<HTMLDivElement>(null);
  const [hoveredTech, setHoveredTech] = useState<string | null>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Tech tags animation
      const tags = cloudRef.current?.querySelectorAll('.tech-tag');
      if (tags) {
        gsap.fromTo(
          tags,
          { scale: 0, opacity: 0 },
          {
            scale: 1,
            opacity: 1,
            duration: 0.6,
            stagger: {
              each: 0.05,
              from: 'random',
            },
            ease: 'back.out(1.7)',
            scrollTrigger: {
              trigger: cloudRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Get connected techs
  const getConnectedTechs = (techName: string) => {
    const tech = technologies.find(t => t.name === techName);
    return tech?.connections || [];
  };

  const isConnected = (techName: string) => {
    if (!hoveredTech) return true;
    if (techName === hoveredTech) return true;
    return getConnectedTechs(hoveredTech).includes(techName);
  };

  return (
    <section
      id="tech"
      ref={sectionRef}
      className="relative min-h-screen w-full flex items-center py-20 px-4 sm:px-8 lg:px-16"
    >
      <div className="max-w-7xl mx-auto w-full">
        {/* Title */}
        <div ref={titleRef} className="text-center mb-16 opacity-0">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            技术<span className="gradient-text">栈</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            构建宇宙模拟的工具与技能
          </p>
        </div>

        {/* Tech Cloud */}
        <div
          ref={cloudRef}
          className="relative flex flex-wrap justify-center gap-4 max-w-4xl mx-auto"
        >
          {technologies.map((tech, index) => {
            const connected = isConnected(tech.name);
            const isHovered = hoveredTech === tech.name;
            
            return (
              <div
                key={index}
                className={`tech-tag relative group cursor-pointer transition-all duration-300 ${
                  hoveredTech && !connected ? 'opacity-20' : 'opacity-100'
                }`}
                onMouseEnter={() => setHoveredTech(tech.name)}
                onMouseLeave={() => setHoveredTech(null)}
              >
                <div
                  className={`px-6 py-3 rounded-full border-2 transition-all duration-300 ${
                    isHovered ? 'scale-110' : 'scale-100'
                  }`}
                  style={{
                    borderColor: tech.color,
                    backgroundColor: isHovered ? `${tech.color}30` : `${tech.color}10`,
                    boxShadow: isHovered ? `0 0 20px ${tech.color}50` : 'none',
                  }}
                >
                  <span className="font-mono font-semibold" style={{ color: tech.color }}>
                    {tech.name}
                  </span>
                </div>

                {/* Skill level indicator */}
                {isHovered && (
                  <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap">
                    <div className="text-xs text-gray-400 mb-1">熟练度</div>
                    <div className="w-24 h-1 bg-gray-700 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${tech.level}%`,
                          backgroundColor: tech.color,
                        }}
                      />
                    </div>
                  </div>
                )}

                {/* Connection lines (visual only) */}
                {isHovered && getConnectedTechs(tech.name).length > 0 && (
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2">
                    <div className="text-xs text-gray-500 whitespace-nowrap">
                      关联: {getConnectedTechs(tech.name).join(', ')}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Decorative grid */}
        <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
      </div>

      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-radial from-[#3898ec]/5 via-transparent to-transparent rounded-full blur-3xl" />
    </section>
  );
}
